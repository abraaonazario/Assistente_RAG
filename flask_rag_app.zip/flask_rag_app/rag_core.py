# rag_core.py

import os
import warnings
import pickle
import logging
from typing import List
from dotenv import load_dotenv
# rag_core.py

import os
from dotenv import load_dotenv

# Carrega as variáveis do arquivo .env para o ambiente do sistema
load_dotenv()

# Pega os valores do ambiente e os armazena em variáveis Python
GROQ_API_KEY = os.getenv("GROQ_API_KEY")
GROQ_MODEL = os.getenv("GROQ_MODEL")

# ... resto do seu código ...
# Por exemplo:
from langchain_community.document_loaders import PyPDFLoader
from langchain_groq import ChatGroq
# ... etc ...
# --- LangChain Imports ---
from langchain.schema import Document
from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.memory import MemorySaver
from langchain_community.document_loaders import PyPDFLoader
from langchain_community.retrievers import BM25Retriever
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_chroma import Chroma
from langchain_groq import ChatGroq
from langchain_huggingface import HuggingFaceEmbeddings
from langchain.retrievers import EnsembleRetriever

# --- Initial Configuration ---
warnings.filterwarnings("ignore", category=FutureWarning)
load_dotenv()

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger("RAG_Core")

# --- Environment Variables & Settings ---
# Substitua 'mixtral-8x7b-32768' pelo ID que você encontrou no site da Groq
llm = ChatGroq(temperature=0, model_name="llama-3.1-8b-instant")
GROQ_API_KEY = os.getenv("GROQ_API_KEY")
EMBEDDING_MODEL_NAME = os.getenv("EMBEDDING_MODEL_NAME", "BAAI/bge-m3")
DOCS_PATH = os.getenv("RAG_DOCS_PATH", "./docs")
DB_PATH = os.getenv("RAG_DB_PATH", "./rag_db")
BM25_PICKLE_PATH = os.path.join(DB_PATH, "bm25_retriever.pkl")

# --- Graph State ---
class RAGState(dict):
    question: str
    docs: List[Document]
    answer: str

# --- LLM and Embeddings Initialization ---
try:
    logger.info("Initializing LLM and Embeddings model...")
    LLM = ChatGroq(model=GROQ_MODEL, temperature=0.1, api_key=GROQ_API_KEY)
    EMBEDDINGS = HuggingFaceEmbeddings(
        model_name=EMBEDDING_MODEL_NAME,
        encode_kwargs={"normalize_embeddings": True},
    )
    logger.info("LLM and Embeddings model initialized successfully.")
except Exception as e:
    logger.error(f"Failed to initialize LLM or Embeddings: {e}", exc_info=True)
    raise

# --- Document Processing and Ingestion ---
TEXT_SPLITTER = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=150)

def load_and_chunk_docs(path: str) -> List[Document]:
    files = [os.path.join(path, f) for f in os.listdir(path) if f.endswith(".pdf")]
    all_docs = []
    for file_path in files:
        try:
            loader = PyPDFLoader(file_path)
            all_docs.extend(loader.load())
        except Exception as e:
            logger.error(f"Failed to load {file_path}: {e}")
    
    chunks = TEXT_SPLITTER.split_documents(all_docs)
    logger.info(f"Loaded and chunked {len(all_docs)} pages into {len(chunks)} chunks.")
    return chunks

def ingest_data():
    logger.info("Starting data ingestion process...")
    if not os.path.exists(DOCS_PATH) or not os.listdir(DOCS_PATH):
        logger.error(f"Docs directory '{DOCS_PATH}' is empty or does not exist. Please add PDF files.")
        return

    os.makedirs(DB_PATH, exist_ok=True)
    chunks = load_and_chunk_docs(DOCS_PATH)

    # Create Chroma vector store
    vectorstore = Chroma.from_documents(documents=chunks, embedding=EMBEDDINGS, persist_directory=DB_PATH)
    logger.info("Chroma vector store created and persisted.")

    # Create BM25 retriever
    bm25_retriever = BM25Retriever.from_documents(chunks)
    with open(BM25_PICKLE_PATH, "wb") as f:
        pickle.dump(bm25_retriever, f)
    logger.info(f"BM25 retriever created and saved to {BM25_PICKLE_PATH}.")
    logger.info("Data ingestion completed.")

# --- Retrieval Functions ---
def get_retriever():
    vectorstore = Chroma(persist_directory=DB_PATH, embedding_function=EMBEDDINGS)
    dense_retriever = vectorstore.as_retriever(search_kwargs={"k": 5})
    
    with open(BM25_PICKLE_PATH, "rb") as f:
        bm25_retriever = pickle.load(f)
    bm25_retriever.k = 5
    
    return EnsembleRetriever(retrievers=[dense_retriever, bm25_retriever], weights=[0.5, 0.5])

# --- Graph Nodes ---
def retrieve_node(state: RAGState):
    logger.info("Node: Retrieving documents...")
    retriever = get_retriever()
    docs = retriever.invoke(state["question"])
    logger.info(f"Retrieved {len(docs)} documents.")
    return {"docs": docs}

def format_context(docs: List[Document]) -> str:
    return "\n\n---\n\n".join([doc.page_content for doc in docs])

def answer_node(state: RAGState):
    logger.info("Node: Generating answer...")
    context = format_context(state["docs"])
    
    prompt = f"""Você é um assistente especialista. Use o contexto fornecido para responder à pergunta do usuário de forma clara e concisa.
Se a resposta não estiver no contexto, diga que você não encontrou a informação nos documentos.

Contexto:
{context}

Pergunta:
{state["question"]}

Resposta:
"""
    response = LLM.invoke(prompt)
    return {"answer": response.content}

# --- Graph Construction ---
logger.info("Constructing LangGraph workflow...")
workflow = StateGraph(RAGState)

workflow.add_node("retriever", retrieve_node)
workflow.add_node("answer_generator", answer_node)

workflow.set_entry_point("retriever")
workflow.add_edge("retriever", "answer_generator")
workflow.add_edge("answer_generator", END)

memory = MemorySaver()
app_graph = workflow.compile(checkpointer=memory)
logger.info("Workflow compiled successfully.")


# --- CLI for Ingestion ---
if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="RAG System Data Ingestion")
    parser.add_argument("--ingest", action="store_true", help="Run the data ingestion process.")
    args = parser.parse_args()
    if args.ingest:
        ingest_data()
    else:
        print("To run the data ingestion, use: python rag_core.py --ingest")
        print("To start the web server, use: python app.py")