# app.py

import uuid
from flask import Flask, request, jsonify, render_template
from rag_core import app_graph

app = Flask(__name__)

@app.route('/')
def index():
    """Render the main chat page."""
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    """Handle chat requests."""
    try:
        user_message = request.json['message']
        if not user_message:
            return jsonify({'error': 'Message cannot be empty.'}), 400

        # Each conversation needs a unique thread_id
        thread_id = str(uuid.uuid4())
        thread = {"configurable": {"thread_id": thread_id}}
        
        inputs = {"question": user_message}
        response_content = ""

        # Stream the response from the graph
        for event in app_graph.stream(inputs, thread):
            if "answer_generator" in event:
                response_content = event["answer_generator"].get("answer", "")

        return jsonify({'answer': response_content})

    except Exception as e:
        print(f"Error in /chat endpoint: {e}")
        return jsonify({'error': 'An internal error occurred.'}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000, host='0.0.0.0')