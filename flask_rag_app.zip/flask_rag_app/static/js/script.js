// static/script.js
document.addEventListener('DOMContentLoaded', () => {
    const sendBtn = document.getElementById('send-btn');
    const userInput = document.getElementById('user-input');

    sendBtn.addEventListener('click', sendMessage);
    userInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            e.preventDefault(); // Evita que o form seja enviado (caso exista um)
            sendMessage();
        }
    });
});

async function sendMessage() {
    const userInput = document.getElementById('user-input');
    const messageText = userInput.value.trim();
    if (!messageText) return;

    appendMessage('user', messageText);
    userInput.value = '';
    userInput.focus();

    try {
        const response = await fetch('/chat', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ message: messageText })
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        const botResponse = data.answer || data.error || "Desculpe, não consegui processar a resposta.";
        appendMessage('bot', botResponse);

    } catch (error) {
        console.error('Fetch Error:', error);
        appendMessage('bot', 'Erro de conexão. Não foi possível falar com o assistente.');
    }
}

function appendMessage(sender, text) {
    const chatBox = document.getElementById('chat-box');
    const messageWrapper = document.createElement('div');
    const messageElement = document.createElement('p');
    
    messageWrapper.classList.add('message', `${sender}-message`);
    messageElement.innerText = text;

    messageWrapper.appendChild(messageElement);
    chatBox.appendChild(messageWrapper);
    chatBox.scrollTop = chatBox.scrollHeight;
}